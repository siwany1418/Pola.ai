package com.pola.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.SearchManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.GeolocationPermissions
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * 폴라: full-screen eyes, voice only.
 * The UI lives in assets/index.html. This activity gives the page what a WebView cannot do by itself:
 * continuous speech recognition (SpeechRecognizer), speech output (TextToSpeech), saving photos to the gallery,
 * volume control and camera/microphone permissions.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wantListen = false
    private var speaking = false
    private var savedNotifVolume = -1
    private var ttsRate = 1.0f
    private var ttsPitch = 1.0f
    private var ttsVoiceName: String? = null
    private var ttsGen = 0
    @Volatile private var ttsPending = 0
    private var bargeIn = false

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val micOk = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        js("window.onNativeReady && window.onNativeReady($micOk)")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onGeolocationPermissionsShowPrompt(origin: String, callback: GeolocationPermissions.Callback) {
                    callback.invoke(origin, origin.contains("appassets.androidplatform.net"), false)
                }
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        if (request.origin.host == "appassets.androidplatform.net") request.grant(request.resources)
                        else request.deny()
                    }
                }
            }
            addJavascriptInterface(Bridge(), "Native")
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        initTts(getSharedPreferences("pola", MODE_PRIVATE).getString("ttsEngine", null), false)
    }

    /** (Re)creates the speech engine. engine = null uses the phone's default. */
    private fun initTts(engine: String?, changed: Boolean) {
        ttsReady = false
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) { }
        val listener = TextToSpeech.OnInitListener { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { js("window.onTtsStart && window.onTtsStart()") }
                    override fun onDone(id: String?) { ttsUttDone(id) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { ttsUttDone(id) }
                })
                ttsReady = true
                applyTts()
                js("window.onVoicesChanged && window.onVoicesChanged($changed)")
            } else if (!engine.isNullOrBlank()) {
                getSharedPreferences("pola", MODE_PRIVATE).edit().remove("ttsEngine").apply()
                initTts(null, true)
            }
        }
        tts = if (engine.isNullOrBlank()) TextToSpeech(this, listener) else TextToSpeech(this, listener, engine)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onResume() {
        super.onResume()
        muteBeep(true)
        if (wantListen) listenSoon(300)
    }

    override fun onPause() {
        super.onPause()
        muteBeep(false)
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
    }

    override fun onDestroy() {
        muteBeep(false)
        recognizer?.destroy()
        tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }

    /** The recognizer plays a short beep at every restart. Silence the notification stream while the app is open. */
    private fun muteBeep(on: Boolean) {
        try {
            if (on) {
                if (savedNotifVolume < 0) savedNotifVolume = audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
                audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
            } else if (savedNotifVolume >= 0) {
                audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION, savedNotifVolume, 0)
                savedNotifVolume = -1
            }
        } catch (_: SecurityException) { /* Do Not Disturb policy blocks it; the beep stays */ }
    }

    private fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }
    private fun q(s: String) = JSONObject.quote(s)

    /* ---------- speech out ---------- */
    /** Language first (it resets the voice), then the chosen voice, then speed and pitch. */
    private fun applyTts() {
        val t = tts ?: return
        if (!ttsReady) return
        try {
            t.language = Locale.KOREAN
            val n = ttsVoiceName
            if (!n.isNullOrBlank()) t.voices?.firstOrNull { it.name == n }?.let { t.voice = it }
            t.setPitch(ttsPitch)
            t.setSpeechRate(ttsRate)
        } catch (_: Exception) { }
    }

    /** add = false: speak now (replaces anything queued). add = true: say it after what is already queued. */
    private fun doSpeak(text: String, add: Boolean = false) {
        if (!ttsReady) { js("window.onTtsDone && window.onTtsDone()"); return }
        speaking = true
        if (bargeIn) listenSoon(300) else recognizer?.cancel()
        // ellipses, tildes and quotes make the engine stop and stutter, so they are removed
        val clean = text.replace(Regex("[…~]+|\\.{2,}"), " ").replace(Regex("[\"'“”‘’()]"), "").replace(Regex("\\s+"), " ").trim()
        if (!add) { ttsGen++; ttsPending = 0 }
        ttsPending++
        val r = tts?.speak(clean.ifEmpty { text }, if (add) TextToSpeech.QUEUE_ADD else TextToSpeech.QUEUE_FLUSH, null, "pola$ttsGen")
        if (r != TextToSpeech.SUCCESS) { ttsPending = maxOf(0, ttsPending - 1); if (ttsPending == 0) ttsFinished() }
    }

    /** One queued sentence finished; only when the whole queue is empty is the page told that speech is over. */
    private fun ttsUttDone(id: String?) {
        handler.post {
            if (id != "pola$ttsGen") return@post
            ttsPending--
            if (ttsPending <= 0) { ttsPending = 0; ttsFinished() }
        }
    }

    private fun ttsFinished() {
        speaking = false
        js("window.onTtsDone && window.onTtsDone()")
        if (wantListen) listenSoon(200)
    }

    /* ---------- speech in (continuous: restarts after every result) ---------- */
    private val listenRunnable = Runnable { startRecognition() }

    private fun listenSoon(delay: Long) {
        handler.removeCallbacks(listenRunnable)
        handler.postDelayed(listenRunnable, delay)
    }

    private fun resetRecognizer() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun startRecognition() {
        if (!wantListen || (speaking && !bargeIn)) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // several candidates: the page picks the one that makes sense ("폴라야" is often heard as "포라야")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            // wait a little longer before cutting the sentence off
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 700L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 300L)
            // Android 13+: words the recognizer should lean toward
            putStringArrayListExtra("android.speech.extra.BIASING_STRINGS", arrayListOf(
                "폴라야", "폴라", "설정 보여줘", "사진 찍어줘", "타이머", "알람", "시계 보여줘", "배터리", "이거 뭐야", "잘자", "목소리 바꿔줘", "노래 틀어줘", "다음 곡", "일시정지"))
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) { resetRecognizer(); listenSoon(1000) }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            js("window.onSpeechPartial && window.onSpeechPartial(${q(t)})")
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val t = list?.firstOrNull()
            if (!t.isNullOrBlank()) {
                val alts = JSONArray((list ?: arrayListOf<String>()).drop(1).filter { it.isNotBlank() })
                js("window.onSpeechFinal && window.onSpeechFinal(${q(t)}, $alts)")
            }
            listenSoon(80)
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    wantListen = false
                    js("window.onSpeechState && window.onSpeechState('denied')")
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> { resetRecognizer(); listenSoon(800) }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> listenSoon(3000)
                else -> listenSoon(250) // no match / speech timeout: just listen again
            }
        }
    }

    /* ---------- what the page can call ---------- */
    inner class Bridge {
        @JavascriptInterface fun requestPermissions() {
            runOnUiThread {
                val need = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA, Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE)
                val missing = need.filter { ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) js("window.onNativeReady && window.onNativeReady(true)")
                else permLauncher.launch(missing.toTypedArray())
            }
        }

        @JavascriptInterface fun startListening() { runOnUiThread { wantListen = true; listenSoon(0) } }

        @JavascriptInterface fun stopListening() { runOnUiThread { wantListen = false; recognizer?.cancel() } }

        @JavascriptInterface fun speak(text: String) { runOnUiThread { doSpeak(text) } }

        /** Korean voices installed on the phone, as JSON [{name,label}]. */
        @JavascriptInterface fun voices(): String = try {
            val arr = JSONArray()
            val list = tts?.voices?.filter { it.locale.language == "ko" || it.name.lowercase(Locale.ROOT).startsWith("ko") }
                ?.sortedWith(compareBy<android.speech.tts.Voice>({ -it.quality }, { it.name })) ?: emptyList()
            list.forEachIndexed { i, v ->
                val grade = if (v.quality >= 400) "고음질" else "보통"
                val where = if (v.isNetworkConnectionRequired) "온라인" else "기기 안"
                val need = if (v.features?.contains("notInstalled") == true) " · 내려받기 필요" else ""
                arr.put(JSONObject().put("name", v.name).put("label", "목소리 ${i + 1} · $grade · $where$need (${v.name})"))
            }
            arr.toString()
        } catch (e: Exception) { "[]" }

        /** Speech engines installed on the phone, as JSON [{name,label}]. */
        @JavascriptInterface fun engines(): String = try {
            val arr = JSONArray()
            tts?.engines?.forEach { arr.put(JSONObject().put("name", it.name).put("label", it.label)) }
            arr.toString()
        } catch (e: Exception) { "[]" }

        @JavascriptInterface fun currentEngine(): String = try {
            getSharedPreferences("pola", MODE_PRIVATE).getString("ttsEngine", null) ?: tts?.defaultEngine ?: ""
        } catch (e: Exception) { "" }

        @JavascriptInterface fun setEngine(name: String) {
            runOnUiThread {
                getSharedPreferences("pola", MODE_PRIVATE).edit().putString("ttsEngine", name).apply()
                ttsVoiceName = null
                initTts(name.ifBlank { null }, true)
            }
        }

        /** Opens the phone's text-to-speech settings, where more voices can be downloaded. */
        @JavascriptInterface fun openTtsSettings(): Boolean {
            runOnUiThread {
                try { startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                catch (e: Exception) {
                    try { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
                }
            }
            return true
        }

        /** name = "" for the default voice. */
        @JavascriptInterface fun setVoice(name: String, rate: Double, pitch: Double) {
            runOnUiThread {
                ttsVoiceName = name.ifBlank { null }
                ttsRate = rate.toFloat().coerceIn(0.5f, 2.0f)
                ttsPitch = pitch.toFloat().coerceIn(0.5f, 2.0f)
                applyTts()
            }
        }

        @JavascriptInterface fun stopSpeaking() { runOnUiThread { ttsGen++; ttsPending = 0; tts?.stop(); speaking = false } }

        @JavascriptInterface fun speakAdd(text: String) { runOnUiThread { doSpeak(text, true) } }

        /** Sentences still queued or being spoken. */
        @JavascriptInterface fun pendingSpeech(): Int = ttsPending

        /** Keep listening while speaking, so the stop phrase can interrupt. */
        @JavascriptInterface fun setBarge(on: Boolean) { runOnUiThread { bargeIn = on } }

        /** Saves a JPEG (base64, no data: prefix) to Pictures/Pola. */
        @JavascriptInterface fun savePhoto(b64: String): Boolean = try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val name = "Pola_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Pola")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) false else {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                true
            }
        } catch (e: Exception) { false }

        /** cmd: up, down, max, min. Returns the new volume in percent. */
        @JavascriptInterface fun volume(cmd: String): Int {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            val step = maxOf(1, max / 5)
            val next = when (cmd) {
                "up" -> minOf(max, cur + step)
                "down" -> maxOf(0, cur - step)
                "max" -> max
                "min" -> maxOf(1, max / 5)
                else -> cur
            }
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
            return next * 100 / max
        }

        /* ---------- phone actions ---------- */
        private fun norm(t: String) = t.lowercase(Locale.ROOT).replace(Regex("[\\s·\\-_.]"), "")
        private fun granted(p: String) = ContextCompat.checkSelfPermission(this@MainActivity, p) == PackageManager.PERMISSION_GRANTED
        /** Starts an activity on the UI thread and reports "ok" or the error text, so the page can tell the person what went wrong. */
        private fun go(i: Intent): String {
            val res = arrayOf("")
            val latch = java.util.concurrent.CountDownLatch(1)
            runOnUiThread {
                try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); res[0] = "ok" }
                catch (e: Exception) { res[0] = e.javaClass.simpleName + ": " + (e.message ?: "") }
                latch.countDown()
            }
            latch.await(2, java.util.concurrent.TimeUnit.SECONDS)
            return if (res[0].isEmpty()) "timeout" else res[0]
        }

        private val appAlias = mapOf(
            "카톡" to listOf("카카오톡", "kakaotalk"), "유튜브" to listOf("youtube"), "인스타" to listOf("instagram", "인스타그램"),
            "크롬" to listOf("chrome"), "문자" to listOf("메시지", "messages", "문자"), "메세지" to listOf("메시지", "messages"),
            "전화" to listOf("전화", "phone", "dialer"), "카메라" to listOf("카메라", "camera"), "갤러리" to listOf("갤러리", "gallery", "사진", "photos"),
            "계산기" to listOf("계산기", "calculator"), "시계" to listOf("시계", "clock"), "지도" to listOf("지도", "maps"),
            "구글지도" to listOf("maps", "지도"), "네이버" to listOf("naver", "네이버"), "넷플릭스" to listOf("netflix"), "플레이스토어" to listOf("play store", "플레이스토어", "vending"),
            "설정" to listOf("설정", "settings"), "메모" to listOf("메모", "notes", "memo"), "캘린더" to listOf("캘린더", "calendar", "일정")
        )

        private fun resolveApp(name: String): Pair<String, String>? {
            val q = norm(name).removeSuffix("앱")
            if (q.isEmpty()) return null
            val cands = (listOf(q) + (appAlias[q] ?: emptyList())).map { norm(it) }
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = packageManager.queryIntentActivities(intent, 0).map {
                Triple(norm(it.loadLabel(packageManager).toString()), it.loadLabel(packageManager).toString(), it.activityInfo.packageName)
            }.filter { it.third != packageName }
            for (c in cands) apps.firstOrNull { it.first == c }?.let { return Pair(it.second, it.third) }
            for (c in cands) apps.filter { it.first.contains(c) }.minByOrNull { it.first.length }?.let { return Pair(it.second, it.third) }
            for (c in cands) apps.filter { c.length >= 3 && it.third.lowercase(Locale.ROOT).contains(c) }.minByOrNull { it.third.length }?.let { return Pair(it.second, it.third) }
            for (c in cands) apps.filter { it.first.length >= 2 && c.contains(it.first) }.maxByOrNull { it.first.length }?.let { return Pair(it.second, it.third) }
            return null
        }

        /** Returns the app's label if it exists on this phone, "" otherwise. */
        @JavascriptInterface fun findApp(name: String): String = try { resolveApp(name)?.first ?: "" } catch (e: Exception) { "" }

        @JavascriptInterface fun launchApp(name: String): String = try {
            val r = resolveApp(name)
            val i = r?.let { packageManager.getLaunchIntentForPackage(it.second) }
            if (i != null) go(i) else "앱 실행 정보를 찾지 못했어요"
        } catch (e: Exception) { e.javaClass.simpleName + ": " + (e.message ?: "") }

        /** "display|number", "" (not found) or "noperm". A phone number is accepted as-is. */
        @JavascriptInterface fun findContact(target: String): String = try {
            val digits = target.filter { it.isDigit() || it == '+' }
            if (target.count { it.isDigit() } >= 7) "$digits|$digits"
            else if (!granted(Manifest.permission.READ_CONTACTS)) "noperm"
            else {
                val name = target.trim()
                var best: Pair<String, String>? = null
                contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", arrayOf("%$name%"), null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val n = c.getString(0) ?: continue
                        val num = c.getString(1) ?: continue
                        if (best == null || n.length < best!!.first.length) best = Pair(n, num)
                        if (n == name) { best = Pair(n, num); break }
                    }
                }
                best?.let { it.first + "|" + it.second } ?: ""
            }
        } catch (e: Exception) { "" }

        @JavascriptInterface fun dial(number: String): String = try {
            val uri = Uri.parse("tel:" + Uri.encode(number))
            go(Intent(if (granted(Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        } catch (e: Exception) { e.javaClass.simpleName + ": " + (e.message ?: "") }

        @JavascriptInterface fun smsTo(number: String, body: String): String = try {
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", body))
        } catch (e: Exception) { e.javaClass.simpleName + ": " + (e.message ?: "") }

        @JavascriptInterface fun setAlarm(hour: Int, minute: Int, label: String): String = try {
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
        } catch (e: Exception) { e.javaClass.simpleName + ": " + (e.message ?: "") }


        /** cmd: play, pause, next, prev, stop - controls whatever music app is playing. */
        @JavascriptInterface fun media(cmd: String): String {
            val code = when (cmd) {
                "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
                "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                else -> return "unknown"
            }
            return try {
                audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                audio.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                "ok"
            } catch (e: Exception) { e.javaClass.simpleName }
        }

        /** Opens the YouTube app on the search results for a query (falls back to the browser). */
        @JavascriptInterface fun youtubeSearch(query: String): String = ytOpen("https://www.youtube.com/results?search_query=" + Uri.encode(query))

        /** Opens the YouTube app straight on a video. */
        @JavascriptInterface fun youtubeWatch(videoId: String): String = ytOpen("https://www.youtube.com/watch?v=" + Uri.encode(videoId))

        private fun ytOpen(url: String): String {
            val r = go(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage("com.google.android.youtube"))
            return if (r == "ok") r else go(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }

        private fun jsonText(raw: String?): String = if (raw == null) "" else try { JSONObject("{\"t\":\"$raw\"}").optString("t") } catch (e: Exception) { raw }

        /** Finds the first video for a query in the background, then calls window.onYtFound(id, videoId, title, channel). */
        @JavascriptInterface fun ytSearch(id: String, query: String) {
            thread {
                var vid = ""; var title = ""; var chan = ""
                try {
                    val c = (URL("https://www.youtube.com/results?hl=ko&gl=KR&sp=EgIQAQ%253D%253D&search_query=" + Uri.encode(query)).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 5000; readTimeout = 6000
                        setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36")
                        setRequestProperty("Accept-Language", "ko-KR,ko;q=0.9")
                    }
                    val html = c.inputStream.bufferedReader().use { it.readText() }
                    val m = Regex("\"videoRenderer\":\\{\"videoId\":\"([A-Za-z0-9_-]{11})\"").find(html)
                    if (m != null) {
                        vid = m.groupValues[1]
                        val tail = html.substring(m.range.last, minOf(html.length, m.range.last + 4000))
                        val text = "((?:[^\"\\\\]|\\\\.)*)"
                        title = jsonText(Regex("\"title\":\\{\"runs\":\\[\\{\"text\":\"" + text + "\"").find(tail)?.groupValues?.get(1))
                        chan = jsonText(Regex("\"ownerText\":\\{\"runs\":\\[\\{\"text\":\"" + text + "\"").find(tail)?.groupValues?.get(1))
                    }
                } catch (_: Exception) { }
                js("window.onYtFound && window.onYtFound(${q(id)}, ${q(vid)}, ${q(title)}, ${q(chan)})")
            }
        }

        @JavascriptInterface fun webSearch(q: String): String = try {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        } catch (e: Exception) { e.javaClass.simpleName + ": " + (e.message ?: "") }
    }
}
