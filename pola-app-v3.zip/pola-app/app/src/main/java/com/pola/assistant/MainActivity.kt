package com.pola.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 폴라: full-screen eyes, voice only.
 * The UI lives in assets/index.html. This activity gives the page what a WebView cannot do by itself:
 * continuous speech recognition (SpeechRecognizer), speech output (TextToSpeech), saving photos to the gallery,
 * volume control and camera/microphone permissions.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var audio: AudioManager
    private val handler = Handler(Looper.getMainLooper())

    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wantListen = false
    private var speaking = false
    private var savedNotifVolume = -1
    private var ttsRate = 1.05f
    private var ttsPitch = 1.2f
    private var ttsVoiceName: String? = null

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val micOk = r[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        js("window.onNativeReady && window.onNativeReady($micOk)")
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.attributes = window.attributes.apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web = WebView(this).apply {
            setBackgroundColor(0xFF000000.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                    assetLoader.shouldInterceptRequest(request.url)
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    runOnUiThread {
                        if (request.origin.host == "appassets.androidplatform.net") request.grant(request.resources)
                        else request.deny()
                    }
                }
            }
            addJavascriptInterface(Bridge(), "Native")
        }
        setContentView(web)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { js("window.onTtsStart && window.onTtsStart()") }
                    override fun onDone(id: String?) { ttsFinished() }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { ttsFinished() }
                })
                ttsReady = true
                applyTts()
            }
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            val c = WindowInsetsControllerCompat(window, window.decorView)
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onResume() {
        super.onResume()
        muteBeep(true)
        if (wantListen) listenSoon(300)
    }

    override fun onPause() {
        super.onPause()
        muteBeep(false)
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel()
    }

    override fun onDestroy() {
        muteBeep(false)
        recognizer?.destroy()
        tts?.shutdown()
        web.destroy()
        super.onDestroy()
    }

    /** The recognizer plays a short beep at every restart. Silence the notification stream while the app is open. */
    private fun muteBeep(on: Boolean) {
        try {
            if (on) {
                if (savedNotifVolume < 0) savedNotifVolume = audio.getStreamVolume(AudioManager.STREAM_NOTIFICATION)
                audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 0, 0)
            } else if (savedNotifVolume >= 0) {
                audio.setStreamVolume(AudioManager.STREAM_NOTIFICATION, savedNotifVolume, 0)
                savedNotifVolume = -1
            }
        } catch (_: SecurityException) { /* Do Not Disturb policy blocks it; the beep stays */ }
    }

    private fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }
    private fun q(s: String) = JSONObject.quote(s)

    /* ---------- speech out ---------- */
    /** Language first (it resets the voice), then the chosen voice, then speed and pitch. */
    private fun applyTts() {
        val t = tts ?: return
        if (!ttsReady) return
        try {
            t.language = Locale.KOREAN
            val n = ttsVoiceName
            if (!n.isNullOrBlank()) t.voices?.firstOrNull { it.name == n }?.let { t.voice = it }
            t.setPitch(ttsPitch)
            t.setSpeechRate(ttsRate)
        } catch (_: Exception) { }
    }

    private fun doSpeak(text: String) {
        if (!ttsReady) { js("window.onTtsDone && window.onTtsDone()"); return }
        speaking = true
        recognizer?.cancel()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "pola")
    }

    private fun ttsFinished() {
        speaking = false
        js("window.onTtsDone && window.onTtsDone()")
        if (wantListen) listenSoon(500)
    }

    /* ---------- speech in (continuous: restarts after every result) ---------- */
    private val listenRunnable = Runnable { startRecognition() }

    private fun listenSoon(delay: Long) {
        handler.removeCallbacks(listenRunnable)
        handler.postDelayed(listenRunnable, delay)
    }

    private fun resetRecognizer() {
        recognizer?.destroy()
        recognizer = null
    }

    private fun startRecognition() {
        if (!wantListen || speaking) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            // several candidates: the page picks the one that makes sense ("폴라야" is often heard as "포라야")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            // wait a little longer before cutting the sentence off
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1200L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 700L)
            // Android 13+: words the recognizer should lean toward
            putStringArrayListExtra("android.speech.extra.BIASING_STRINGS", arrayListOf(
                "폴라야", "폴라", "설정 보여줘", "사진 찍어줘", "타이머", "알람", "시계 보여줘", "배터리", "이거 뭐야", "잘자", "목소리 바꿔줘"))
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try { recognizer?.startListening(intent) } catch (e: Exception) { resetRecognizer(); listenSoon(1000) }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onPartialResults(partialResults: Bundle?) {
            val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
            js("window.onSpeechPartial && window.onSpeechPartial(${q(t)})")
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val t = list?.firstOrNull()
            if (!t.isNullOrBlank()) {
                val alts = JSONArray(list.drop(1).filter { it.isNotBlank() })
                js("window.onSpeechFinal && window.onSpeechFinal(${q(t)}, $alts)")
            }
            listenSoon(150)
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    wantListen = false
                    js("window.onSpeechState && window.onSpeechState('denied')")
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> { resetRecognizer(); listenSoon(800) }
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> listenSoon(3000)
                else -> listenSoon(250) // no match / speech timeout: just listen again
            }
        }
    }

    /* ---------- what the page can call ---------- */
    inner class Bridge {
        @JavascriptInterface fun requestPermissions() {
            runOnUiThread {
                val need = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
                val missing = need.filter { ContextCompat.checkSelfPermission(this@MainActivity, it) != PackageManager.PERMISSION_GRANTED }
                if (missing.isEmpty()) js("window.onNativeReady && window.onNativeReady(true)")
                else permLauncher.launch(missing.toTypedArray())
            }
        }

        @JavascriptInterface fun startListening() { runOnUiThread { wantListen = true; listenSoon(0) } }

        @JavascriptInterface fun stopListening() { runOnUiThread { wantListen = false; recognizer?.cancel() } }

        @JavascriptInterface fun speak(text: String) { runOnUiThread { doSpeak(text) } }

        /** Korean voices installed on the phone, as JSON [{name,label}]. */
        @JavascriptInterface fun voices(): String = try {
            val arr = JSONArray()
            val list = tts?.voices?.filter { it.locale.language == "ko" }?.sortedWith(compareBy({ -it.quality }, { it.name })) ?: emptyList()
            list.forEachIndexed { i, v ->
                val q = if (v.quality >= 400) "고음질" else "보통"
                val where = if (v.isNetworkConnectionRequired) "온라인" else "기기 안"
                arr.put(JSONObject().put("name", v.name).put("label", "목소리 ${i + 1} · $q · $where"))
            }
            arr.toString()
        } catch (e: Exception) { "[]" }

        /** name = "" for the default voice. */
        @JavascriptInterface fun setVoice(name: String, rate: Double, pitch: Double) {
            runOnUiThread {
                ttsVoiceName = name.ifBlank { null }
                ttsRate = rate.toFloat().coerceIn(0.5f, 2.0f)
                ttsPitch = pitch.toFloat().coerceIn(0.5f, 2.0f)
                applyTts()
            }
        }

        @JavascriptInterface fun stopSpeaking() { runOnUiThread { tts?.stop(); speaking = false } }

        /** Saves a JPEG (base64, no data: prefix) to Pictures/Pola. */
        @JavascriptInterface fun savePhoto(b64: String): Boolean = try {
            val bytes = Base64.decode(b64, Base64.DEFAULT)
            val name = "Pola_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".jpg"
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, name)
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Pola")
                put(MediaStore.Images.Media.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) false else {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                values.clear()
                values.put(MediaStore.Images.Media.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
                true
            }
        } catch (e: Exception) { false }

        /** cmd: up, down, max, min. Returns the new volume in percent. */
        @JavascriptInterface fun volume(cmd: String): Int {
            val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            val step = maxOf(1, max / 5)
            val next = when (cmd) {
                "up" -> minOf(max, cur + step)
                "down" -> maxOf(0, cur - step)
                "max" -> max
                "min" -> maxOf(1, max / 5)
                else -> cur
            }
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
            return next * 100 / max
        }
    }
}
